//import 'dart:js_interop';

import 'package:flutter_tex/flutter_tex.dart';

import 'package:flutter_math_fork/ast.dart';
import 'package:flutter_math_fork/flutter_math.dart';
import 'package:flutter_math_fork/tex.dart';



Future<String> convertBinaryToDecimal(String binaryValue) async {
  try {
    int decimal = int.parse(binaryValue, radix: 2);
    String stepsToSolve = '';
    int lenght = binaryValue.length;
    var digits = binaryValue.split('');
    int power = lenght-1;
    for (int i = 0; i < lenght; i++) {
      int check1or0;
      if(i==0) {
        check1or0 = int.parse(digits[i], radix: 2);
        stepsToSolve = "$stepsToSolve\n$check1or0* \ 2^$power \ ";

      }
      else{
        check1or0 = int.parse(digits[i], radix: 2);
       
        stepsToSolve = stepsToSolve + "\n +" + check1or0.toString() + "* 2^" + power.toString();
      }
      power = power - 1;
          }
    return   "\n" +stepsToSolve + " = " + decimal.toString();
  } catch (e) {
    return 'Invalid Input';
  }
}

Future<String> convertDecimalToBinary(String decimalValue) async {
  try {
    int decimal = int.parse(decimalValue, radix: 10);
    String binary = decimal.toRadixString(2);
    
    return binary;
  } catch (e) {
    return 'Invalid Input';
  }
}

Future<String> convertDecimalToHex(String decimalValue) async {
  try {
    int decimal = int.parse(decimalValue, radix: 10);
    String hexa = decimal.toRadixString(16);

    return hexa;
  } catch (e) {
    return 'Invalid Input';
  }
}



